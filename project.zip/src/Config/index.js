export const APP_PREFIX = 'easyboiler://';
export const BASE_URL = 'https://voice-flask-api.herokuapp.com';
// export const BASE_URL = 'https://audiogrocery.herokuapp.com/';
