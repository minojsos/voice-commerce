import defaultTheme from './configs/default';

export default defaultTheme;
